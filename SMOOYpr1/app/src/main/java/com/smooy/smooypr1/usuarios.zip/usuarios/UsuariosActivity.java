package com.example.smooypr1.usuarios;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smooypr1.API.ApiClient;
import com.example.smooypr1.API.ApiService;
import com.example.smooypr1.R;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UsuariosActivity extends AppCompatActivity {

    private static final String TAG = "UsuariosActivity";
    
    private RecyclerView recyclerViewUsuarios;
    private UsuarioAdapter usuarioAdapter;
    private Button btnVolver;
    private MaterialButton btnAgregarUsuario;
    private List<Usuario> usuarios = new ArrayList<>();
    private int usuarioId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usuarios);

        inicializarVistas();
        configurarRecyclerView();
        configurarBotones();
        
        iniciarCarga();
    }
    
    private void inicializarVistas() {
        recyclerViewUsuarios = findViewById(R.id.recyclerViewUsuarios);
        btnVolver = findViewById(R.id.btnVolver);
        btnAgregarUsuario = findViewById(R.id.btnAgregarUsuario);
    }
    
    private void configurarRecyclerView() {
        recyclerViewUsuarios.setLayoutManager(new LinearLayoutManager(this));
        usuarioAdapter = new UsuarioAdapter(this, usuarios);
        recyclerViewUsuarios.setAdapter(usuarioAdapter);
        
        usuarioAdapter.setOnDeleteClickListener((usuario, position) -> {
            // Diálogo de confirmación para eliminar
            new AlertDialog.Builder(this)
                .setTitle("Eliminar usuario")
                .setMessage("¿Está seguro que desea eliminar a " + usuario.getNombreCompleto() + "?")
                .setPositiveButton("Eliminar", (dialog, which) -> eliminarUsuario(usuario.getId(), position))
                .setNegativeButton("Cancelar", null)
                .show();
        });
    }
    
    private void configurarBotones() {
        btnVolver.setOnClickListener(v -> finish());
        
        btnAgregarUsuario.setOnClickListener(v -> {
            Intent intent = new Intent(UsuariosActivity.this, CrearUsuariosActivity.class);
            startActivity(intent);
        });
    }
    
    private void cargarUsuarios() {
        Log.d(TAG, "Iniciando carga de usuarios...");
        
        ApiService apiService = ApiClient.getApiService();
        Call<Map<String, List<Usuario>>> call = apiService.obtenerUsuarios();
        
        call.enqueue(new Callback<Map<String, List<Usuario>>>() {
            @Override
            public void onResponse(Call<Map<String, List<Usuario>>> call, Response<Map<String, List<Usuario>>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Map<String, List<Usuario>> data = response.body();
                    List<Usuario> listaUsuarios = data.get("usuarios");
                    
                    Log.d(TAG, "Usuarios recibidos del servidor: " + (listaUsuarios != null ? listaUsuarios.size() : 0));
                    
                    if (listaUsuarios != null && !listaUsuarios.isEmpty()) {
                        // Agrupar usuarios por ID para eliminar duplicados
                        Map<Integer, Usuario> usuariosMap = new HashMap<>();
                        
                        for (Usuario usuario : listaUsuarios) {
                            int id = usuario.getId();
                            
                            if (usuariosMap.containsKey(id)) {
                                // Este usuario ya existe, agregar su establecimiento a la lista
                                Usuario usuarioExistente = usuariosMap.get(id);
                                List<Map<String, Object>> establecimientos = usuarioExistente.getEstablecimientos();
                                
                                // Crear un mapa con la información del establecimiento actual
                                if (usuario.getEstablecimientoId() > 0 && usuario.getEstablecimientoNombre() != null) {
                                    Map<String, Object> establecimiento = new HashMap<>();
                                    establecimiento.put("id", usuario.getEstablecimientoId());
                                    establecimiento.put("nombre", usuario.getEstablecimientoNombre());
                                    
                                    // Verificar si este establecimiento ya está en la lista
                                    boolean establecimientoExiste = false;
                                    for (Map<String, Object> est : establecimientos) {
                                        if (est.get("id").equals(usuario.getEstablecimientoId())) {
                                            establecimientoExiste = true;
                                            break;
                                        }
                                    }
                                    
                                    if (!establecimientoExiste) {
                                        establecimientos.add(establecimiento);
                                    }
                                }
                            } else {
                                // Nuevo usuario, inicializar su lista de establecimientos
                                List<Map<String, Object>> establecimientos = new ArrayList<>();
                                
                                if (usuario.getEstablecimientoId() > 0 && usuario.getEstablecimientoNombre() != null) {
                                    Map<String, Object> establecimiento = new HashMap<>();
                                    establecimiento.put("id", usuario.getEstablecimientoId());
                                    establecimiento.put("nombre", usuario.getEstablecimientoNombre());
                                    establecimientos.add(establecimiento);
                                }
                                
                                usuario.setEstablecimientos(establecimientos);
                                usuariosMap.put(id, usuario);
                            }
                        }
                        
                        // Convertir el mapa a una lista
                        List<Usuario> usuariosUnicos = new ArrayList<>(usuariosMap.values());
                        
                        Log.d(TAG, "Usuarios únicos después de agrupar: " + usuariosUnicos.size());
                        
                        // Actualizar la UI con los usuarios agrupados
                        usuarios.clear();
                        usuarios.addAll(usuariosUnicos);
                        usuarioAdapter.actualizarLista(usuarios);
                    } else {
                        Toast.makeText(UsuariosActivity.this, "No hay usuarios disponibles", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Manejar error en la respuesta
                    Log.e(TAG, "Error en la respuesta: " + response.code());
                    try {
                        String errorBody = response.errorBody() != null ? response.errorBody().string() : "Error desconocido";
                        Log.e(TAG, "Cuerpo del error: " + errorBody);
                        Toast.makeText(UsuariosActivity.this, "Error al cargar usuarios: " + errorBody, Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Log.e(TAG, "Error al leer cuerpo de error", e);
                    }
                }
            }

            @Override
            public void onFailure(Call<Map<String, List<Usuario>>> call, Throwable t) {
                Log.e(TAG, "Error en la solicitud", t);
                Toast.makeText(UsuariosActivity.this, "Error de conexión: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    
    private void eliminarUsuario(int usuarioId, int position) {
        ApiService apiService = ApiClient.getApiService();
        Call<Map<String, Object>> call = apiService.eliminarUsuario(usuarioId);
        
        call.enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Map<String, Object> resultado = response.body();
                    boolean success = (boolean) resultado.getOrDefault("success", false);
                    
                    if (success) {
                        Toast.makeText(UsuariosActivity.this, "Usuario eliminado con éxito", Toast.LENGTH_SHORT).show();
                        usuarioAdapter.eliminarUsuario(position);
                    } else {
                        String mensaje = (String) resultado.getOrDefault("message", "Error desconocido");
                        Toast.makeText(UsuariosActivity.this, mensaje, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(UsuariosActivity.this, "Error al eliminar usuario: " + response.code(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                Log.e(TAG, "Error en la solicitud", t);
                Toast.makeText(UsuariosActivity.this, "Error de conexión: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        cargarUsuarios(); // Recargar usuarios al volver a la pantalla
    }

    private void iniciarCarga() {
        // Obtener información del usuario actual desde SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        usuarioId = sharedPreferences.getInt("USER_ID", -1);
        String rolUsuario = sharedPreferences.getString("ROL_USUARIO", "");
        int establecimientoId = sharedPreferences.getInt("ESTABLECIMIENTO_ID", -1);
        
        Log.d(TAG, "Datos cargados: Usuario ID=" + usuarioId + 
              ", Rol=" + rolUsuario + 
              ", Establecimiento ID=" + establecimientoId);
        
        if (usuarioId == -1 || rolUsuario.isEmpty()) {
            Toast.makeText(this, "Error: No se pudo obtener información del usuario", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        
        // Continuar con la carga de usuarios
        cargarUsuarios();
    }
}