package com.example.smooypr1.usuarios;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.smooypr1.API.ApiClient;
import com.example.smooypr1.API.ApiService;
import com.example.smooypr1.Establecimientos;
import com.example.smooypr1.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CrearUsuariosActivity extends AppCompatActivity {
    private static final String TAG = "CrearUsuariosActivity";

    private EditText etNombre, etApellido, etNombreUsuario, etContraseña;
    private Spinner spRol;
    private Button btnCrear, btnVolver, btnAddEstablecimiento;
    private LinearLayout containerEstablecimientos;

    // Lista de establecimientos disponibles
    private List<Establecimientos> establecimientos = new ArrayList<>();
    
    // Lista de establecimientos seleccionados por el usuario
    private List<Establecimientos> establecimientosSeleccionados = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_usuarios);

        inicializarVistas();
        cargarRoles();
        cargarEstablecimientos();
        configurarBotones();
    }

    private void inicializarVistas() {
        etNombre = findViewById(R.id.etNombre);
        etApellido = findViewById(R.id.etApellido);
        etNombreUsuario = findViewById(R.id.etNombreUsuario);
        etContraseña = findViewById(R.id.etContraseña);
        spRol = findViewById(R.id.spRol);
        btnCrear = findViewById(R.id.btnCrear);
        btnVolver = findViewById(R.id.btnVolver);
        btnAddEstablecimiento = findViewById(R.id.btnAddEstablecimiento);
        containerEstablecimientos = findViewById(R.id.containerEstablecimientos);
    }

    private void cargarRoles() {
        // Configurar el Spinner de roles
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.roles_array,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spRol.setAdapter(adapter);
    }

    private void cargarEstablecimientos() {
        ApiService apiService = ApiClient.getApiService();
        Call<Map<String, List<Establecimientos>>> call = apiService.obtenerEstablecimientos();
        
        call.enqueue(new Callback<Map<String, List<Establecimientos>>>() {
            @Override
            public void onResponse(Call<Map<String, List<Establecimientos>>> call, Response<Map<String, List<Establecimientos>>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Map<String, List<Establecimientos>> data = response.body();
                    List<Establecimientos> listaEstablecimientos = data.get("establecimientos");
                    
                    if (listaEstablecimientos != null && !listaEstablecimientos.isEmpty()) {
                        establecimientos.clear();
                        establecimientos.addAll(listaEstablecimientos);
                        Log.d(TAG, "Establecimientos cargados: " + establecimientos.size());
                        
                        // Habilitar el botón para añadir establecimientos
                        btnAddEstablecimiento.setEnabled(true);
                    } else {
                        Log.e(TAG, "No se encontraron establecimientos");
                        Toast.makeText(CrearUsuariosActivity.this, "No hay establecimientos disponibles", Toast.LENGTH_SHORT).show();
                        btnAddEstablecimiento.setEnabled(false);
                    }
                } else {
                    Log.e(TAG, "Error en la respuesta: " + response.code());
                    Toast.makeText(CrearUsuariosActivity.this, "Error al cargar establecimientos", Toast.LENGTH_SHORT).show();
                    btnAddEstablecimiento.setEnabled(false);
                }
            }

            @Override
            public void onFailure(Call<Map<String, List<Establecimientos>>> call, Throwable t) {
                Log.e(TAG, "Error de conexión", t);
                Toast.makeText(CrearUsuariosActivity.this, "Error de conexión", Toast.LENGTH_SHORT).show();
                btnAddEstablecimiento.setEnabled(false);
            }
        });
    }

    private void configurarBotones() {
        btnVolver.setOnClickListener(v -> finish());
        
        btnCrear.setOnClickListener(v -> validarYCrearUsuario());
        
        btnAddEstablecimiento.setOnClickListener(v -> mostrarDialogoEstablecimientos());
    }
    
    private void mostrarDialogoEstablecimientos() {
        if (establecimientos.isEmpty()) {
            Toast.makeText(this, "No hay establecimientos disponibles", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Crear un array con los nombres de establecimientos para el diálogo
        String[] nombresEstablecimientos = new String[establecimientos.size()];
        for (int i = 0; i < establecimientos.size(); i++) {
            nombresEstablecimientos[i] = establecimientos.get(i).getNombre();
        }
        
        // Crear y mostrar el diálogo de selección
        new AlertDialog.Builder(this)
            .setTitle("Seleccionar Establecimiento")
            .setItems(nombresEstablecimientos, (dialog, which) -> {
                Establecimientos seleccionado = establecimientos.get(which);
                
                // Verificar si ya está seleccionado
                boolean yaSeleccionado = false;
                for (Establecimientos e : establecimientosSeleccionados) {
                    if (e.getId() == seleccionado.getId()) {
                        yaSeleccionado = true;
                        break;
                    }
                }
                
                if (yaSeleccionado) {
                    Toast.makeText(this, "Este establecimiento ya está seleccionado", Toast.LENGTH_SHORT).show();
                } else {
                    // Añadir a la lista de seleccionados
                    establecimientosSeleccionados.add(seleccionado);
                    
                    // Añadir a la UI
                    agregarEstablecimientoAUI(seleccionado);
                }
            })
            .setNegativeButton("Cancelar", null)
            .show();
    }
    
    private void agregarEstablecimientoAUI(Establecimientos establecimiento) {
        // Inflar la vista del establecimiento seleccionado
        View view = LayoutInflater.from(this).inflate(
                R.layout.item_establecimiento_seleccionado, 
                containerEstablecimientos, 
                false);
        
        // Configurar la vista
        TextView tvNombre = view.findViewById(R.id.tvNombreEstablecimiento);
        ImageButton btnRemove = view.findViewById(R.id.btnRemoveEstablecimiento);
        
        tvNombre.setText(establecimiento.getNombre());
        
        // Guardar el ID del establecimiento como tag para identificarlo al eliminar
        view.setTag(establecimiento.getId());
        
        // Configurar el botón para eliminar
        btnRemove.setOnClickListener(v -> {
            // Eliminar de la UI
            containerEstablecimientos.removeView(view);
            
            // Eliminar de la lista de seleccionados
            establecimientosSeleccionados.removeIf(e -> e.getId() == establecimiento.getId());
        });
        
        // Añadir a la UI
        containerEstablecimientos.addView(view);
    }

    private void validarYCrearUsuario() {
        // Obtener valores de los campos
        String nombre = etNombre.getText().toString().trim();
        String apellido = etApellido.getText().toString().trim();
        String nombreUsuario = etNombreUsuario.getText().toString().trim();
        String contraseña = etContraseña.getText().toString().trim();
        String rol = spRol.getSelectedItem().toString();
        
        // Validar que los campos no estén vacíos
        if (nombre.isEmpty() || apellido.isEmpty() || nombreUsuario.isEmpty() || contraseña.isEmpty()) {
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Crear un mapa con los datos del usuario
        Map<String, Object> usuarioMap = new HashMap<>();
        usuarioMap.put("nombre", nombre);
        usuarioMap.put("apellido", apellido);
        usuarioMap.put("usuario", nombreUsuario);
        usuarioMap.put("contraseña", contraseña);
        usuarioMap.put("rol", rol);
        
        // Añadir los IDs de establecimientos seleccionados
        List<Integer> idsEstablecimientos = new ArrayList<>();
        for (Establecimientos e : establecimientosSeleccionados) {
            idsEstablecimientos.add(e.getId());
        }
        usuarioMap.put("establecimientos", idsEstablecimientos);
        
        // Llamar a la API para crear el usuario
        crearUsuario(usuarioMap);
    }
    
    private void crearUsuario(Map<String, Object> usuarioMap) {
        ApiService apiService = ApiClient.getApiService();
        Call<Map<String, Object>> call = apiService.crearUsuario(usuarioMap);
        
        call.enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Map<String, Object> resultado = response.body();
                    
                    // Verificar si fue exitoso
                    boolean success = (boolean) resultado.getOrDefault("success", false);
                    String mensaje = (String) resultado.getOrDefault("message", "");
                    
                    if (success) {
                        Toast.makeText(CrearUsuariosActivity.this, "Usuario creado correctamente", Toast.LENGTH_SHORT).show();
                        
                        // Añadir un breve retraso antes de cerrar para mostrar el mensaje
                        new Handler().postDelayed(() -> {
                            finish(); // Esto cierra la actividad actual y vuelve a MenuActivity
                        }, 1500); // Esperar 1.5 segundos para mostrar el mensaje
                    } else {
                        Toast.makeText(CrearUsuariosActivity.this, mensaje, Toast.LENGTH_LONG).show();
                    }
                } else {
                    try {
                        String errorBody = response.errorBody().string();
                        Log.e(TAG, "Error: " + errorBody);
                        Toast.makeText(CrearUsuariosActivity.this, "Error: " + errorBody, Toast.LENGTH_LONG).show();
                    } catch (Exception e) {
                        Log.e(TAG, "Error al procesar respuesta de error", e);
                        Toast.makeText(CrearUsuariosActivity.this, "Error al crear usuario: " + response.code(), Toast.LENGTH_LONG).show();
                    }
                }
            }
            
            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                Log.e(TAG, "Error de conexión", t);
                Toast.makeText(CrearUsuariosActivity.this, "Error de conexión: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    
    private void limpiarCampos() {
        etNombre.setText("");
        etApellido.setText("");
        etNombreUsuario.setText("");
        etContraseña.setText("");
        spRol.setSelection(0);
        containerEstablecimientos.removeAllViews();
        establecimientosSeleccionados.clear();
    }
}